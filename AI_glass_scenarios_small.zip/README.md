# AI 글래스 시나리오 공유용 파일

이 폴더에 있는 **index.html, shopping-mate.html, docent-mode.html** 3개 파일을 GitHub 저장소 루트(최상위 위치)에 업로드하세요.

세 HTML 파일에 이미지와 음성 데이터가 모두 포함되어 있어서 `assets` 폴더가 필요하지 않습니다.

## GitHub 업로드

1. ZIP 압축을 풉니다. **ZIP 자체를 GitHub에 업로드하지 마세요.**
2. GitHub `irene0427-cmyk/AI_glass_scenarios` 저장소를 열어 `Add file` > `Upload files`를 누릅니다.
3. `index.html`, `shopping-mate.html`, `docent-mode.html` 3개를 한꺼번에 끌어놓고 `Commit changes`를 누릅니다.
4. 저장소 `Settings` > `Pages` > `Build and deployment` > `Deploy from a branch` > `main` > `/(root)` > `Save`를 누릅니다.
5. 게시가 완료되면 https://irene0427-cmyk.github.io/AI_glass_scenarios/ 에서 확인하세요.

모든 이미지가 고품질 WebP로 최적화되었으며 시나리오와 음성은 유지되었습니다.
